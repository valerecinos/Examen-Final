/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bancos1;

/**
 *
 * @author valer
 */
public class Bancos1 {

    public static void main(String[] args) {
       CuentasForm obj = new CuentasForm();
       obj.setVisible(true);
       MovimientoForm form= new MovimientoForm();
       form.setVisible(true);
       
    }
}
