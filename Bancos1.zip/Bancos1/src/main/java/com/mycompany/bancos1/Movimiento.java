/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancos1;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JTextField;
/**
 *
 * @author valer
 */
public class Movimiento {
    
    String codigo,Fecha;
    float Cantidad;
    int id,id_mov; 

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String Fecha) {
        this.Fecha = Fecha;
    }

    public float getCantidad() {
        return Cantidad;
    }

    public void setCantidad(float Cantidad) {
        this.Cantidad = Cantidad;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_mov() {
        return id_mov;
    }

    public void setId_mov(int id_mov) {
        this.id_mov = id_mov;
    }
    public void InsertarMovimiento(JTextField codigo,JTextField mov, JTextField cantidad,JTextField Fecha){
      Connection connection = null;
           String insert="INSERT INTO Movimiento (codigo,id_mov,cantidad,fecha) VALUES(?,?,?,NOW())";
           DBConnection objetoConexion = new DBConnection();
           connection = objetoConexion.establecerConexion();
           setCodigo(codigo.getText());
           setId_mov(Integer.parseInt(mov.getText()));
           setCantidad(Float.parseFloat(cantidad.getText()));
           
           try(PreparedStatement ps = connection.prepareStatement(insert)){
                ps.setString(1,getCodigo());
            ps.setInt(2,getId_mov());
            ps.setFloat(3,getCantidad());
            ps.execute();
            System.out.println("Movimiento insertado");
        }catch(Exception e){
            System.out.println("Error:"+e);
        }
    }
           }
             
    

