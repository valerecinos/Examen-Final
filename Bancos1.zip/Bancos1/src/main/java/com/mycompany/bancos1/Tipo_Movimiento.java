/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancos1;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JTextField;
/**
 *
 * @author valer
 */
public class Tipo_Movimiento {
    String tipo;
    int id;

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
     public void insertMovimiento(JTextField tipo){
        Connection connection = null;
        String insert="insert into TIPO_MOVIMIENTO (Tipo) VALUES(?)";
        DBConnection objetoConexion = new DBConnection();
        connection = objetoConexion.establecerConexion();
        setTipo(tipo.getText());
        try(PreparedStatement ps = connection.prepareStatement(insert)){
            ps.setString(1,getTipo());
            ps.execute();
            System.out.println("Movimiento insertado");
        }catch(Exception e){
            System.out.println("Error: "+e);
        }
    }
    public void updateMovimiento(JTextField Tipo, JTextField codigo){
        Connection connection = null;
        String insert="update TIPO_MOVIMIENTO set tipo=? where id_mov=?";
        DBConnection objetoConexion = new DBConnection();
        connection = objetoConexion.establecerConexion();
        setTipo(Tipo.getText());
        setId(Integer.parseInt(codigo.getText()));
        try(PreparedStatement ps = connection.prepareStatement(insert)){
            ps.setString(1,getTipo());
            ps.setInt(2,getId());
            ps.execute();
            System.out.println("Movimiento Actualizado");
        }catch(Exception e){
            System.out.println("Error: "+e);
        }
    }
    public void deleteMovimiento(JTextField codigo){
        setId(Integer.parseInt(codigo.getText()));
        Connection connection = null;
        String insert="delete from TIPO_MOVIMIENTO where id_mov=?";
        DBConnection objetoConexion = new DBConnection();
        connection = objetoConexion.establecerConexion();
        try(PreparedStatement ps = connection.prepareStatement(insert)){
            ps.setInt(1,getId());
            ps.execute();
            System.out.println("Movimiento Eliminado");
        }catch(Exception e){
            System.out.println("Error: "+e);
        }
    }
}
