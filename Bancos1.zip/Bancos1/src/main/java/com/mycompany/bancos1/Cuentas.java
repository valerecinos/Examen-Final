/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancos1;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JTextField;
/**
/**
 *
 * @author valer
 */
public class Cuentas {

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }
    
    String cliente, email, codigo;
    float saldo;
    

 public void insertCuenta (JTextField Codigo,JTextField Cliente, JTextField Email, JTextField Saldo){
     Connection connection = null;
     
     setCodigo(Codigo.getText());
     setCliente(Cliente.getText());
     setEmail(Email.getText());
     setSaldo(Float.parseFloat(Saldo.getText()));
     
     String insert = "INSERT INTO CUENTAS(codigo, cliente, email, saldo) VALUES(?,?,?,?)";
     DBConnection objetoConexion = new DBConnection();
     connection = objetoConexion.establecerConexion();
     
     try (PreparedStatement ps = connection.prepareStatement(insert)){
         ps.setString(1, getCodigo());
         ps.setString(2, getCliente());
         ps.setString(3, getEmail());
         ps.setFloat(4, getSaldo());
         ps.execute();
         
         System.out.println("Cuenta Creada");
     }
     catch (Exception e){
         System.out.println("Error: "+ e.getMessage());
     }
    }
     
    public void updateCuenta(JTextField Codigo, JTextField Saldo){
        Connection connection = null;
        setCodigo(Codigo.getText());
        setSaldo(Float.parseFloat(Saldo.getText()));
        String update = "update CUENTAS set SALDO= ? where codigo=?";
        
        DBConnection objetoConexion = new DBConnection();
        connection = objetoConexion.establecerConexion();
        
        try(PreparedStatement ps = connection.prepareStatement(update)){
            ps.setFloat(1, getSaldo());
            ps.setString(2, getCodigo());
            ps.execute();
            System.out.println("Cuenta Actualizada");
        }
        catch(Exception e){
            System.out.println("Error: "+ e);
        }
    }
    
    public void deleteCuenta(JTextField Codigo){
        setCodigo(Codigo.getText());
        Connection connection = null;
        String insert = "delete from CUENTAS where codigo = ?";
        DBConnection objetoConexion = new DBConnection();
        connection = objetoConexion.establecerConexion();
        
        try (PreparedStatement ps = connection.prepareStatement(insert)){
            ps.setString(1, getCodigo());
            ps.execute();
            System.out.println("Cuenta Eliminada");
        }catch (Exception e){
            System.out.println("Error: "+e);
        }
        }
}

